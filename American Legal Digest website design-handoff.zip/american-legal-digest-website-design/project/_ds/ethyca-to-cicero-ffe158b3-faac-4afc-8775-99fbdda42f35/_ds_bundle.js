/* @ds-bundle: {"format":4,"namespace":"EthycaDesignSystem_95c503","components":[{"name":"Link","sourcePath":"components/accents/Link.jsx"},{"name":"PullQuote","sourcePath":"components/accents/PullQuote.jsx"},{"name":"Stat","sourcePath":"components/accents/Stat.jsx"},{"name":"PixelChevron","sourcePath":"components/core/Button.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Cta","sourcePath":"ui_kits/website/Cta.jsx"},{"name":"Customers","sourcePath":"ui_kits/website/Customers.jsx"},{"name":"Footer","sourcePath":"ui_kits/website/Footer.jsx"},{"name":"Header","sourcePath":"ui_kits/website/Header.jsx"},{"name":"Hero","sourcePath":"ui_kits/website/Hero.jsx"},{"name":"Impact","sourcePath":"ui_kits/website/Impact.jsx"},{"name":"LearnMore","sourcePath":"ui_kits/website/LearnMore.jsx"},{"name":"Logo","sourcePath":"ui_kits/website/Logo.jsx"},{"name":"PlatformStack","sourcePath":"ui_kits/website/PlatformStack.jsx"},{"name":"ProductMark","sourcePath":"ui_kits/website/ProductMark.jsx"},{"name":"PRODUCT_META","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductHero","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductOverview","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductFeatures","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductBand","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductCrossLinks","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductCta","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"ProductPage","sourcePath":"ui_kits/website/ProductPage.jsx"},{"name":"Statement","sourcePath":"ui_kits/website/Statement.jsx"}],"sourceHashes":{"components/accents/Link.jsx":"bb161624346c","components/accents/PullQuote.jsx":"a711510d030a","components/accents/Stat.jsx":"7fcbf304a814","components/core/Button.jsx":"0d9294eb1893","components/core/Card.jsx":"883bef5fcbc8","components/core/Eyebrow.jsx":"9160fb9d6a0b","components/core/Tag.jsx":"5d00393de024","ui_kits/website/Cta.jsx":"30418ac2ee3a","ui_kits/website/Customers.jsx":"3dcb282145bd","ui_kits/website/Footer.jsx":"cecb05dd1447","ui_kits/website/Header.jsx":"b5fa76aa2565","ui_kits/website/Hero.jsx":"fb1849c55b84","ui_kits/website/Impact.jsx":"5eb4b17690b4","ui_kits/website/LearnMore.jsx":"929c974e83c7","ui_kits/website/Logo.jsx":"9794fd10a9b9","ui_kits/website/PlatformStack.jsx":"1bcfd7289c59","ui_kits/website/ProductMark.jsx":"2b4fcbc27cb2","ui_kits/website/ProductPage.jsx":"35626c2fa960","ui_kits/website/Statement.jsx":"1bd9614ee049","ui_kits/website/tweaks-panel.jsx":"6591467622ed"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EthycaDesignSystem_95c503 = window.EthycaDesignSystem_95c503 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/accents/Link.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Link — an inline text link in the brand voice. Ink at rest, shifting to
 * the accent (--link-hover) with a growing hairline underline on hover;
 * `accent` renders it in the accent colour at rest instead. An optional
 * trailing arrow nudges right on hover. Calm and expo-eased — no bounce.
 */
function Link({
  children,
  href,
  arrow = false,
  accent = false,
  inverse = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const base = inverse ? "var(--ink-inverse)" : "var(--ink)";
  const color = accent ? "var(--accent)" : hover ? "var(--link-hover)" : base;
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      color,
      fontFamily: "var(--font-body)",
      textDecoration: "none",
      borderBottom: "1px solid",
      borderBottomColor: hover || accent ? "currentColor" : "transparent",
      transition: "var(--transition-color), border-color var(--duration) var(--ease-expo-out)",
      ...style
    }
  }), children, arrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      transition: "transform var(--duration) var(--ease-expo-out)",
      transform: hover ? "translateX(3px)" : "none"
    }
  }, "\u2192"));
}
Object.assign(__ds_scope, { Link });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/accents/Link.jsx", error: String((e && e.message) || e) }); }

// components/accents/PullQuote.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * PullQuote — an editorial pull quote: a short accent rule, an eliza
 * statement set tight, and an optional mono attribution. The rule is the
 * only colour and reads from --accent. No big quotation marks, no border
 * box — punctuation, not decoration.
 */
function PullQuote({
  children,
  cite,
  inverse = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("figure", _extends({}, rest, {
    style: {
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 40,
      height: 2,
      background: "var(--accent)",
      flex: "none"
    }
  }), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontSize: "clamp(1.5rem, 2.4vw, 2rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.15,
      textWrap: "balance",
      color: inverse ? "var(--ink-inverse)" : "var(--ink)"
    }
  }, children), cite && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-mono)",
      letterSpacing: "var(--tracking-mono)",
      textTransform: "uppercase",
      color: inverse ? "var(--ink-inverse-muted)" : "var(--ink-muted)"
    }
  }, cite));
}
Object.assign(__ds_scope, { PullQuote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/accents/PullQuote.jsx", error: String((e && e.message) || e) }); }

// components/accents/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Stat — an editorial metric. A short accent rule (the only colour), a
 * large eliza figure, and a mono caption beneath. The rule reads from
 * --accent, so it re-themes with the active section accent.
 */
function Stat({
  figure,
  label,
  rule = true,
  inverse = false,
  align = "left",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      alignItems: align === "center" ? "center" : "flex-start",
      textAlign: align,
      ...style
    }
  }), rule && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 32,
      height: 2,
      background: "var(--accent)",
      flex: "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(2.5rem, 4vw, 3.5rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1,
      color: inverse ? "var(--ink-inverse)" : "var(--ink)"
    }
  }, figure), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-mono)",
      letterSpacing: "var(--tracking-mono)",
      textTransform: "uppercase",
      lineHeight: 1.3,
      color: inverse ? "var(--ink-inverse-muted)" : "var(--ink-muted)"
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/accents/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cicero Button — the brand's pill:
 * 2px radius, basierSquare at line-height 1, 12×14px padding, 48px tall.
 * Split form = label segment + square icon segment with a 1px gap;
 * both segments change together on hover (group-hover).
 * All fills/hovers are the values extracted from the live CSS.
 */

/** The site's pixel-art chevron (8×4), used in split CTAs. */
function PixelChevron({
  size = 8
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size / 2,
    viewBox: "0 0 8 4",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "1.71484",
    y: "1.5",
    width: "1.14286",
    height: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    width: "1.14286",
    height: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "3.42773",
    y: "3",
    width: "1.14286",
    height: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "5.14258",
    y: "1.5",
    width: "1.14286",
    height: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "6.85742",
    width: "1.14286",
    height: "1",
    fill: "currentColor"
  }));
}
const BUTTON_VARIANTS = {
  /* primary CTA: bg-minos hover:bg-dark-minos */
  dark: {
    bg: "var(--color-minos)",
    color: "var(--color-white)",
    hoverBg: "var(--color-dark-minos)",
    hoverColor: "var(--color-white)"
  },
  /* on dark sections: bg-white hover:bg-dark-minos hover:text-white */
  light: {
    bg: "var(--color-white)",
    color: "var(--color-minos)",
    hoverBg: "var(--color-dark-minos)",
    hoverColor: "var(--color-white)"
  },
  /* on the minos product band: bg-[#3E3F40] hover:bg-[#8C8C8C] */
  onDark: {
    bg: "var(--color-btn-on-dark)",
    color: "var(--color-white)",
    hoverBg: "var(--color-btn-on-dark-hover)",
    hoverColor: "var(--color-white)"
  },
  /* over imagery/video: translucent + backdrop-blur, hover solidifies to minos */
  blurDark: {
    bg: "var(--color-btn-blur-dark)",
    color: "var(--color-white)",
    hoverBg: "var(--color-minos)",
    hoverColor: "var(--color-white)",
    blur: true
  },
  blurWarm: {
    bg: "var(--color-btn-blur-warm)",
    color: "var(--color-minos)",
    hoverBg: "var(--color-minos)",
    hoverColor: "var(--color-white)",
    blur: true
  },
  /* footer subscribe: bg-black hover:bg-white */
  black: {
    bg: "var(--color-black)",
    color: "var(--color-white)",
    hoverBg: "var(--color-white)",
    hoverColor: "var(--color-minos)"
  }
};
function Button({
  children,
  variant = "dark",
  withArrow = false,
  icon,
  href,
  onClick,
  disabled = false,
  type = "button",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const p = BUTTON_VARIANTS[variant] || BUTTON_VARIANTS.dark;
  const active = hover && !disabled;
  const seg = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    boxSizing: "border-box",
    height: 48,
    minHeight: 48,
    background: active ? p.hoverBg : p.bg,
    color: active ? p.hoverColor : p.color,
    backdropFilter: p.blur ? "blur(12px)" : undefined,
    WebkitBackdropFilter: p.blur ? "blur(12px)" : undefined,
    borderRadius: "var(--radius-xs)",
    fontFamily: "var(--font-body)",
    fontSize: "1rem",
    lineHeight: "1em",
    transition: "var(--transition-color)",
    whiteSpace: "nowrap",
    overflow: "hidden"
  };
  const labelSeg = {
    ...seg,
    padding: "14px 12px"
  };
  const iconSeg = {
    ...seg,
    minWidth: 48,
    width: 48,
    padding: 0
  };
  const TagEl = href ? "a" : "button";
  const rootProps = href ? {
    href,
    "aria-disabled": disabled || undefined
  } : {
    type,
    onClick,
    disabled
  };
  const iconNode = icon !== undefined ? icon : /*#__PURE__*/React.createElement(PixelChevron, null);
  return /*#__PURE__*/React.createElement(TagEl, _extends({}, rootProps, rest, {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "stretch",
      gap: 1,
      padding: 0,
      border: "none",
      background: "transparent",
      textDecoration: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: labelSeg
  }, children), withArrow && /*#__PURE__*/React.createElement("span", {
    style: iconSeg
  }, iconNode));
}
Object.assign(__ds_scope, { PixelChevron, Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — a flat surface separated by hairlines, not shadows. Optional
 * dashed top rule (the site's section/grid divider). Surface variants
 * map to the paper / warm / ink palette.
 */
function Card({
  children,
  surface = "paper",
  dashedTop = false,
  padded = true,
  style,
  ...rest
}) {
  const surfaces = {
    paper: {
      bg: "var(--surface)",
      color: "var(--ink)"
    },
    warm: {
      bg: "var(--surface-warm)",
      color: "var(--ink)"
    },
    dark: {
      bg: "var(--surface-dark)",
      color: "var(--ink-inverse)"
    },
    darkest: {
      bg: "var(--surface-darkest)",
      color: "var(--ink-inverse)"
    }
  };
  const s = surfaces[surface] || surfaces.paper;
  const onDark = surface === "dark" || surface === "darkest";
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      position: "relative",
      background: s.bg,
      color: s.color,
      border: onDark ? "var(--border-hairline-dark)" : "var(--border-hairline)",
      borderRadius: "var(--radius-md)",
      padding: padded ? "var(--space-6)" : 0,
      ...style
    }
  }), dashedTop && /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 1,
      color: s.color,
      opacity: 0.3,
      backgroundImage: "var(--dashed-rule-image)"
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Eyebrow — the brand's mono section label. Uppercase basierSquareMono
 * with +0.05em tracking, optionally prefixed by a step number rendered
 * as "NN | Label" (the site's numbered-section convention).
 */
function Eyebrow({
  number,
  children,
  inverse = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-mono)",
      lineHeight: "var(--leading-mono)",
      letterSpacing: "var(--tracking-mono)",
      textTransform: "uppercase",
      color: inverse ? "var(--ink-inverse-muted)" : "var(--ink-muted)",
      ...style
    }
  }), number != null && /*#__PURE__*/React.createElement("span", {
    style: {
      color: inverse ? "var(--ink-inverse)" : "var(--ink)"
    }
  }, number, " | "), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tag — a small mono pill for product names, categories and metadata.
 * Hairline outline by default; `solid` fills with ink. A `dot` color
 * may be supplied to prefix a small status/brand marker.
 */
function Tag({
  children,
  solid = false,
  dot,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "7px",
      fontFamily: "var(--font-mono)",
      fontSize: "0.6875rem",
      lineHeight: 1,
      letterSpacing: "var(--tracking-mono)",
      textTransform: "uppercase",
      padding: "6px 10px",
      borderRadius: "var(--radius-sm)",
      background: solid ? "var(--surface-dark)" : "transparent",
      color: solid ? "var(--ink-inverse)" : "var(--ink)",
      border: solid ? "none" : "var(--border-hairline)",
      ...style
    }
  }), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "var(--radius-full)",
      background: dot,
      flex: "none"
    }
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Cta.jsx
try { (() => {
/** Closing CTA — black band with the real video frame at 80% opacity,
 *  two stacked eliza lines (second muted), white split CTA. */
function Cta() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      background: "var(--color-black)",
      color: "var(--color-white)",
      padding: 24,
      overflow: "hidden",
      marginBottom: -1
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      opacity: 0.8,
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/images/cta-video-poster.jpg",
    alt: "",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 28,
      letterSpacing: "-0.03em",
      lineHeight: 1.1,
      margin: 0
    }
  }, "A senior legal partner in your pocket."), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 28,
      letterSpacing: "-0.03em",
      lineHeight: 1.1,
      margin: 0,
      opacity: 0.5
    }
  }, "Just text it."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      marginTop: 208
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "light"
  }, "Speak with us"))));
}
Object.assign(__ds_scope, { Cta });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Cta.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Customers.jsx
try { (() => {
/* Customers (04) — Cicero is built with modern legal teams. No customer
   logos; segments are listed over dashed top rules with a one-line
   description of how each uses Cicero. */
const SEGMENTS = [{
  name: "Full-service firm",
  use: "Standardize drafting and review across every practice group."
}, {
  name: "Boutique litigation",
  use: "First drafts of filings and responses, ready the same day."
}, {
  name: "In-house legal",
  use: "Contracts requested, negotiated, and signed without the backlog."
}, {
  name: "Tax & advisory",
  use: "Opinions and memos packaged as fixed-price products."
}, {
  name: "Labor practice",
  use: "High-volume, repeatable matters run on templates, not retyping."
}, {
  name: "Independent lawyers",
  use: "Sell finished expertise through the network — no firm required."
}];
function SegmentCell({
  s
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: 12,
      padding: "20px 0 8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 1,
      color: "var(--ink)",
      opacity: 0.3,
      backgroundImage: "var(--dashed-rule-image)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: "var(--ink)"
    }
  }, s.name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 18,
      lineHeight: 1.3,
      letterSpacing: "var(--tracking-display)",
      margin: 0,
      color: "var(--ink-muted)",
      maxWidth: "30ch"
    }
  }, s.use));
}
function Customers() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid-12",
    style: {
      padding: "56px 24px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 6"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "04 | Customers"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(2rem, 2.4vw, 2.25rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.1,
      margin: "16px 0 0"
    }
  }, "Built with modern legal teams ", /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "from solo lawyers to full-service firms")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 28,
      margin: "0 24px",
      paddingBottom: 64
    }
  }, SEGMENTS.map(s => /*#__PURE__*/React.createElement(SegmentCell, {
    key: s.name,
    s: s
  }))));
}
Object.assign(__ds_scope, { Customers });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Customers.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
const COLUMNS = [{
  head: "Platform",
  items: ["How it works", "↳ Foederati", "↳ Feira", "↳ Scriba", "↳ Custodia", "↳ Magus", "↳ Stoa"]
}, {
  head: "Company",
  items: ["About Cicero", "Customers", "Pricing", "Careers", "Contact"]
}, {
  head: "Connect",
  items: ["Insights", "Guides", "LinkedIn", "WhatsApp"]
}];

/* Footer link — mono uppercase at 50%, hovering paints a white capsule
   behind the text and flips it to minos (the site's signature hover). */
function FooterLink({
  children
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      zIndex: 2,
      textDecoration: "none",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-mono)",
      letterSpacing: "var(--tracking-mono)",
      textTransform: "uppercase",
      lineHeight: 1,
      padding: "2px",
      margin: "-2px -2px 2px",
      color: hover ? "var(--color-minos)" : "var(--color-white)",
      opacity: hover ? 1 : 0.5,
      background: hover ? "var(--color-white)" : "transparent",
      alignSelf: "flex-start"
    }
  }, children);
}
function NewsletterForm() {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("form", {
    style: {
      width: "100%"
    },
    onSubmit: e => e.preventDefault()
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      marginBottom: 16,
      color: "var(--color-white)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Law moves fast. Build it on finished work."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      opacity: 0.5
    }
  }, "Subscribe for insights on modern legal practice.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    placeholder: "EMAIL ADDRESS",
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      height: 48,
      background: "var(--color-dark-minos)",
      border: "1px solid " + (focus ? "rgba(255,255,255,0.4)" : "transparent"),
      borderRadius: "var(--radius-xs)",
      outline: "none",
      padding: "0 16px",
      color: "var(--color-white)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-mono)",
      letterSpacing: "var(--tracking-mono)",
      textTransform: "uppercase",
      transition: "border-color var(--duration) var(--ease-expo-out)"
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "black",
    type: "submit",
    style: {
      flex: "none"
    }
  }, "Subscribe")));
}

/** Compact ink footer — links, wordmark, newsletter + info sized to fit
 *  a single viewport (the site themes it via color-changer: #2B2E35/#fff). */
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--color-minos)",
      color: "var(--color-white)",
      maxHeight: "100svh",
      boxSizing: "border-box",
      padding: 24,
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid-12"
  }, COLUMNS.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.head,
    style: {
      gridColumn: "span 3",
      display: "flex",
      flexDirection: "column",
      gap: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      color: "var(--color-white)",
      paddingBottom: 6
    }
  }, col.head), col.items.map(it => /*#__PURE__*/React.createElement(FooterLink, {
    key: it
  }, it))))), /*#__PURE__*/React.createElement("div", {
    className: "grid-12"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    "aria-label": "Cicero",
    style: {
      gridColumn: "span 8",
      color: "var(--color-white)",
      textDecoration: "none",
      fontFamily: "var(--font-display)",
      fontSize: "clamp(3rem, 8vw, 5.5rem)",
      lineHeight: 0.9,
      letterSpacing: "var(--tracking-display)"
    }
  }, "Cicero")), /*#__PURE__*/React.createElement("div", {
    className: "grid-12",
    style: {
      alignItems: "end"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 4"
    }
  }, /*#__PURE__*/React.createElement(NewsletterForm, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 3",
      gridColumnStart: 7,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      color: "var(--color-white)",
      paddingBottom: 6
    }
  }, "Info"), /*#__PURE__*/React.createElement(FooterLink, null, "Trust Center"), /*#__PURE__*/React.createElement(FooterLink, null, "Status"), /*#__PURE__*/React.createElement(FooterLink, null, "Manage Preferences")), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 3",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      color: "var(--color-white)",
      paddingBottom: 6
    }
  }, "Legal"), /*#__PURE__*/React.createElement(FooterLink, null, "Privacy"), /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      opacity: 0.5,
      color: "var(--color-white)",
      marginTop: 2
    }
  }, "\xA9 2026 Cicero"))));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
/** Hero — full-viewport black section with a background video (falls back
 *  to the extracted poster frame until a video src is provided), themeable
 *  tint layer (--hero-tint), legibility gradients top + bottom, centered
 *  eliza headline, split CTA bottom-right. */
const POSTER = "../../assets/images/hero-video-poster.jpg";
const COVER = {
  position: "absolute",
  inset: 0,
  width: "100%",
  height: "100%",
  objectFit: "cover"
};
function Hero({
  videoSrc
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      background: "var(--color-black)",
      color: "var(--color-white)",
      height: "100svh",
      minHeight: 640,
      display: "flex",
      flexDirection: "column",
      padding: 24,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0
    }
  }, videoSrc ? /*#__PURE__*/React.createElement("video", {
    autoPlay: true,
    muted: true,
    loop: true,
    playsInline: true,
    src: videoSrc,
    poster: POSTER,
    style: COVER
  }) : /*#__PURE__*/React.createElement("img", {
    src: POSTER,
    alt: "",
    style: COVER
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--hero-tint, transparent)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(to bottom, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0) 26%, rgba(0,0,0,0) 62%, rgba(0,0,0,0.45) 100%)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2,
      flex: 1,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(3rem, 5.5vw, 4.5rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.1,
      textAlign: "center",
      textWrap: "balance",
      maxWidth: "30ch",
      margin: 0
    }
  }, "Finished legal work \u2014 drafted, reviewed, signed, filed"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 18,
      lineHeight: 1.45,
      textAlign: "center",
      textWrap: "balance",
      maxWidth: "52ch",
      margin: 0,
      opacity: 0.75
    }
  }, "Cicero is the AI legal platform: lawyers draft, redline, sign, and file in one place \u2014 and clients buy finished legal work at a fixed price.")), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: "stretch",
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "blurDark",
    withArrow: true
  }, "Speak with us"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "dark",
    withArrow: true
  }, "See the platform"))));
}
Object.assign(__ds_scope, { Hero });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Impact.jsx
try { (() => {
/* Impact section (05) — heading with muted clause, then testimonial cards:
   dashed top rule, eliza quote, mono role attribution at 60%. Cicero's
   customers are legal teams, quoted by role rather than by logo. */
const TESTIMONIALS = [{
  quote: "Cicero gives our associates their evenings back. The first draft is already done.",
  who: ["Managing partner", "Full-service firm"]
}, {
  quote: "We answer clients in hours, not days — and the work comes back finished, not as a to-do.",
  who: ["Head of legal", "In-house"]
}, {
  quote: "Every contract has a clear next step now. Nothing sits in someone's inbox.",
  who: ["Operations lead", "Boutique litigation"]
}, {
  quote: "It looks up the case by its docket number and drafts the response. It just works.",
  who: ["Senior associate", "Civil litigation"]
}];
function TestimonialCard({
  t
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 3",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      gap: 80
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      height: 1,
      width: "100%",
      color: "var(--ink)",
      backgroundImage: "var(--dashed-rule-image)",
      marginBottom: 24
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 18,
      lineHeight: 1.3,
      letterSpacing: "var(--tracking-display)"
    }
  }, t.quote)), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      opacity: 0.6,
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, t.who.map(w => /*#__PURE__*/React.createElement("span", {
    key: w
  }, w))));
}
function Impact() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      borderTop: "var(--border-hairline)",
      paddingTop: 16
    }
  }, /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      padding: "8px 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 8"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "05 | Impact"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(2rem, 2.4vw, 2.25rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.1,
      margin: "16px 0 0"
    }
  }, "Trusted by leaders in ", /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "modern legal practice")))), /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      padding: "0 24px 64px"
    }
  }, TESTIMONIALS.map(t => /*#__PURE__*/React.createElement(TestimonialCard, {
    key: t.who[0],
    t: t
  }))));
}
Object.assign(__ds_scope, { Impact });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Impact.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/LearnMore.jsx
try { (() => {
/* Learn-more section (06) — sandstone hairline, mono label, then two large
   image cards (16:10-ish). The card image sits at 80% opacity in a rounded
   frame and FADES OUT on hover (the site's signature reveal), leaving the
   hairline-bordered card with ink text. */
const CARDS = [{
  title: "How it works",
  desc: "See how Cicero turns a request into finished, filed legal work",
  img: "../../assets/images/how-it-works.avif",
  alt: "A person sitting in front of a computer screen with code, in black and white."
}, {
  title: "About Cicero",
  desc: "Learn how Cicero is building the AI legal platform",
  img: "../../assets/images/hero-poster.avif",
  alt: "A loft startup office with people walking and working, in black and white."
}];
function LearnMoreCard({
  c
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    "aria-label": c.title,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      gridColumn: "span 6",
      position: "relative",
      aspectRatio: "1.6 / 1",
      padding: 16,
      textDecoration: "none",
      color: hover ? "var(--ink)" : "var(--color-white)",
      transition: "color var(--duration) var(--ease-expo-out)",
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      border: "1px solid rgba(0,0,0,0.15)",
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      borderRadius: "var(--radius-xl)",
      overflow: "hidden",
      opacity: hover ? 0 : 0.8,
      transition: "opacity var(--duration) var(--ease-expo-out)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: c.img,
    alt: c.alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      zIndex: 4,
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 24,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.1
    }
  }, c.title), /*#__PURE__*/React.createElement("span", {
    style: {
      alignSelf: "flex-end",
      maxWidth: "30ch",
      fontFamily: "var(--font-body)",
      fontSize: 16,
      lineHeight: 1.4
    }
  }, c.desc)));
}
function LearnMore() {
  return /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      background: "var(--surface)",
      padding: "0 24px 64px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1",
      height: 1,
      background: "var(--color-sandstone)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      gridColumn: "1 / -1",
      marginBottom: 32
    }
  }, "06 | Learn more"), CARDS.map(c => /*#__PURE__*/React.createElement(LearnMoreCard, {
    key: c.title,
    c: c
  })));
}
Object.assign(__ds_scope, { LearnMore });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/LearnMore.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cicero logotype — set in the display serif (eliza). `width` controls the
 * optical size; `color` tints it (currentColor by default).
 */
function Logo({
  width = 92,
  color = "currentColor",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "img",
    "aria-label": "Cicero"
  }, rest, {
    style: {
      display: "inline-block",
      fontFamily: "var(--font-display)",
      fontSize: width * 0.34,
      lineHeight: 1,
      letterSpacing: "var(--tracking-display)",
      color,
      ...style
    }
  }), "Cicero");
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Logo.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
/* Fixed header on the 12-col grid: wordmark (cols 1–2), body-1 nav with
   pixel-chevron dropdowns, blur "Login" CTA right (the "speak with us"
   CTA lives in the hero). The site re-themes
   the header per section (color-changer); over the hero it renders white. */
const NAV = [{
  label: "How it works"
}, {
  label: "Platform",
  dropdown: true
}, {
  label: "About Cicero"
}, {
  label: "Resources",
  dropdown: true
}];
function Header({
  ink = "var(--color-white)",
  buttonVariant = "blurDark"
}) {
  const [hovered, setHovered] = React.useState(null);
  return /*#__PURE__*/React.createElement("header", {
    className: "grid-12",
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 40,
      alignItems: "center",
      padding: "24px",
      color: ink
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "./index.html",
    "aria-label": "Cicero",
    style: {
      gridColumn: "span 2",
      color: "inherit",
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    width: 74,
    color: "currentColor"
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      gridColumn: "3 / span 8",
      display: "flex",
      gap: 4
    }
  }, NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.label,
    href: "#",
    onMouseEnter: () => setHovered(n.label),
    onMouseLeave: () => setHovered(null),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      color: "inherit",
      textDecoration: "none",
      fontFamily: "var(--font-body)",
      fontSize: 16,
      lineHeight: 1.4,
      padding: "16px 12px",
      opacity: hovered && hovered !== n.label ? 0.5 : 1,
      transition: "opacity var(--duration) var(--ease-expo-out)"
    }
  }, n.label, n.dropdown && /*#__PURE__*/React.createElement(__ds_scope.PixelChevron, null)))), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 2",
      display: "flex",
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: buttonVariant
  }, "Login")));
}
Object.assign(__ds_scope, { Header });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProductMark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Product marks — the six Cicero products (Foederati, Feira, Scriba, Custodia,
 * Magus, Stoa) are set as serif wordmarks in the display face; there are no
 * separate icon glyphs. kind: "wordmark" (the product name) or "icon" (a small
 * rotated-square diamond dot in the current ink).
 */
function ProductMark({
  product,
  kind = "wordmark",
  height = 28,
  color = "currentColor",
  style,
  ...rest
}) {
  if (kind === "icon") {
    return /*#__PURE__*/React.createElement("span", _extends({
      "aria-hidden": "true"
    }, rest, {
      style: {
        display: "inline-block",
        width: height * 0.62,
        height: height * 0.62,
        background: color,
        transform: "rotate(45deg)",
        flex: "none",
        ...style
      }
    }));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "img",
    "aria-label": product
  }, rest, {
    style: {
      display: "inline-block",
      fontFamily: "var(--font-display)",
      fontSize: height,
      lineHeight: 1,
      letterSpacing: "var(--tracking-display)",
      color,
      ...style
    }
  }), product);
}
Object.assign(__ds_scope, { ProductMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProductMark.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PlatformStack.jsx
try { (() => {
/* Exact band surfaces & sticky-stack mechanics from the live site:
   each product contributes a thin 72px header row that sticks at
   top = index*72 (so headers accumulate), followed by its detail band.
   Each header carries a blunt, direct product description with the key
   phrase painted as a highlight (inverted capsule). */
const PRODUCTS = [{
  name: "Foederati",
  surface: "#2B4631",
  ink: "var(--color-white)",
  dark: true,
  btn: "blurDark",
  soon: true,
  tagPre: "The",
  tagHl: "network of specialists",
  tagPost: "",
  step: "1 · For lawyers",
  desc: "Where independent lawyers package their expertise into sellable products."
}, {
  name: "Feira",
  surface: "#6F6842",
  ink: "var(--color-white)",
  dark: true,
  btn: "blurDark",
  soon: true,
  tagPre: "The",
  tagHl: "solution showcase",
  tagPost: "",
  step: "2 · For clients",
  desc: "Where clients buy finished legal work — fixed scope, fixed price, signed in minutes."
}, {
  name: "Scriba",
  surface: "#53635F",
  ink: "var(--color-white)",
  dark: true,
  btn: "blurDark",
  tagPre: "",
  tagHl: "Write, redline, create",
  tagPost: "",
  step: "3 · Write faster",
  desc: "AI drafting and redlining built for how lawyers actually write."
}, {
  name: "Custodia",
  surface: "#B8C6BA",
  ink: "var(--color-minos)",
  btn: "light",
  tagPre: "Document &",
  tagHl: "contract lifecycle management",
  tagPost: "",
  step: "4 · Never lose a doc",
  desc: "Every contract and document — organized, tracked, findable."
}, {
  name: "Magus",
  surface: "#2F4648",
  ink: "var(--color-white)",
  dark: true,
  btn: "blurDark",
  tagPre: "The",
  tagHl: "AI assistant",
  tagPost: "in email & WhatsApp",
  step: "5 · Where you work",
  desc: "Meets you where you already work — WhatsApp, email, anywhere."
}, {
  name: "Stoa",
  surface: "#486140",
  ink: "var(--color-white)",
  dark: true,
  btn: "blurDark",
  tagPre: "",
  tagHl: "Matter & client management",
  tagPost: "",
  step: "6 · Run the practice",
  desc: "The calm operating system for the practice — intake, matters, and tasks in order."
}];
const HEADER_H = 72;

/** Small "SOON" pill — outline capsule in the band's ink. */
function SoonBadge() {
  return /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 10,
      lineHeight: 1,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      border: "1px solid currentColor",
      borderRadius: 999,
      padding: "3px 7px 2px",
      opacity: 0.9,
      flex: "none"
    }
  }, "Soon");
}

/** Thin collapsed header row — the blunt product description with its
 *  highlighted key phrase left (the product name appears once, in the
 *  detail band below), step right. */
function StackHeader({
  p,
  i
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: i * HEADER_H,
      zIndex: 2,
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid-12",
    style: {
      height: HEADER_H,
      background: p.surface,
      color: p.ink,
      padding: "0 24px",
      alignContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      gridColumn: "1 / span 9",
      display: "flex",
      alignItems: "center",
      gap: 8,
      textTransform: "uppercase",
      whiteSpace: "nowrap"
    }
  }, p.tagPre && /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, p.tagPre), /*#__PURE__*/React.createElement("span", {
    style: {
      background: p.ink,
      color: p.surface,
      padding: "3px 6px 2px",
      borderRadius: "var(--radius-xs)"
    }
  }, p.tagHl), p.tagPost && /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, p.tagPost), p.soon && /*#__PURE__*/React.createElement(SoonBadge, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "11 / span 2",
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      opacity: 0.5
    }
  }, p.step))));
}

/** Detail band — product wordmark left, eliza description + Learn More. */
function StackDetail({
  p
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      position: "relative",
      zIndex: 1,
      background: p.surface,
      color: p.ink,
      padding: "32px 24px",
      minHeight: 340,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 4",
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.ProductMark, {
    product: p.name,
    kind: "wordmark",
    height: 32,
    color: p.ink
  }), p.soon && /*#__PURE__*/React.createElement(SoonBadge, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 4",
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 20,
      lineHeight: 1.3,
      letterSpacing: "var(--tracking-display)",
      margin: 0,
      maxWidth: 280
    }
  }, p.desc), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: p.btn,
    withArrow: true,
    href: `./${p.name}.html`
  }, "Learn More"))));
}
function PlatformStack() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)"
    }
  }, /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      position: "sticky",
      top: 0,
      minHeight: "100svh",
      background: "var(--surface)",
      padding: 24,
      alignContent: "center",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      position: "absolute",
      top: 24,
      left: 24
    }
  }, "03 | Platform"), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / span 10"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "statement-display",
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(2.5rem, 4.6vw, 4.25rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.05,
      margin: 0,
      textWrap: "balance"
    }
  }, "Six products, one platform: ", /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "sell your expertise, buy finished work, draft and redline, and run every matter, client, and contract in one place.")))), PRODUCTS.map((p, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: p.name
  }, /*#__PURE__*/React.createElement(StackHeader, {
    p: p,
    i: i
  }), /*#__PURE__*/React.createElement(StackDetail, {
    p: p
  }))));
}
Object.assign(__ds_scope, { PlatformStack });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PlatformStack.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProductPage.jsx
try { (() => {
/**
 * ProductPage — the shared sections for the six product subpages
 * (Foederati, Feira, Scriba, Custodia, Magus, Stoa). Each page supplies a
 * data object; the sections follow the homepage's editorial system:
 * numbered mono labels, eliza statements with a 50%-opacity clause,
 * hairline-divided feature rows, a band-colored hero, and the
 * six-product cross-link grid.
 */

const PRODUCT_META = [{
  name: "Foederati",
  surface: "#2B4631",
  dark: true,
  short: "Network"
}, {
  name: "Feira",
  surface: "#6F6842",
  dark: true,
  short: "Marketplace"
}, {
  name: "Scriba",
  surface: "#53635F",
  dark: true,
  short: "Drafting"
}, {
  name: "Custodia",
  surface: "#B8C6BA",
  dark: false,
  short: "Memory"
}, {
  name: "Magus",
  surface: "#2F4648",
  dark: true,
  short: "Assistant"
}, {
  name: "Stoa",
  surface: "#486140",
  dark: true,
  short: "Practice OS"
}];
function SoonBadge() {
  return /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 10,
      lineHeight: 1,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      border: "1px solid currentColor",
      borderRadius: 999,
      padding: "3px 7px 2px",
      opacity: 0.9,
      flex: "none"
    }
  }, "Soon");
}
const DISPLAY = {
  fontFamily: "var(--font-display)",
  letterSpacing: "var(--tracking-display)"
};

/** Full-band hero: grid overlay, bottom-aligned wordmark + tagline + CTAs. */
function ProductHero({
  p
}) {
  const ink = p.dark ? "var(--color-white)" : "var(--color-minos)";
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      background: p.surface,
      color: ink,
      minHeight: "86svh",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      opacity: 0.07,
      backgroundImage: `repeating-linear-gradient(to right, currentColor 0 1px, transparent 1px 64px),` + `repeating-linear-gradient(to bottom, currentColor 0 1px, transparent 1px 64px)`
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Header, {
    ink: ink,
    buttonVariant: p.dark ? "blurDark" : "blurWarm"
  }), /*#__PURE__*/React.createElement("div", {
    className: "grid-12",
    style: {
      position: "relative",
      zIndex: 2,
      flex: 1,
      alignContent: "end",
      padding: "120px 24px 48px",
      rowGap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      gridColumn: "1 / -1",
      display: "flex",
      gap: 20,
      alignItems: "baseline",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.75
    }
  }, p.role), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "Cicero \xB7 ", p.name), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, p.step), p.soon && /*#__PURE__*/React.createElement(SoonBadge, null)), /*#__PURE__*/React.createElement("h1", {
    style: {
      ...DISPLAY,
      gridColumn: "1 / -1",
      margin: 0,
      fontSize: "clamp(3.5rem, 8vw, 6.5rem)",
      lineHeight: 0.95
    }
  }, p.name), /*#__PURE__*/React.createElement("p", {
    style: {
      ...DISPLAY,
      gridColumn: "1 / span 8",
      margin: 0,
      fontSize: "clamp(1.5rem, 2.6vw, 2rem)",
      lineHeight: 1.2,
      maxWidth: "26ch"
    }
  }, p.taglinePre, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.55
    }
  }, p.taglineHl)), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1",
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: p.dark ? "light" : "dark",
    href: p.ctaHref || "#"
  }, p.ctaLabel), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: p.dark ? "blurDark" : "blurWarm",
    href: "./index.html"
  }, "See the platform"))));
}

/** 01 | Overview — big statement with a de-emphasized clause. */
function ProductOverview({
  p
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      background: "var(--surface)",
      padding: "88px 24px",
      borderTop: "var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      gridColumn: "1 / -1",
      color: "var(--ink-muted)"
    }
  }, "01 | Overview"), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...DISPLAY,
      gridColumn: "1 / span 10",
      margin: "18px 0 0",
      fontSize: "clamp(1.9rem, 3.2vw, 2.75rem)",
      lineHeight: 1.15,
      maxWidth: "30ch"
    }
  }, p.overviewPre, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, p.overviewHl)));
}

/** 02 | Features — hairline-divided numbered rows. */
function ProductFeatures({
  p
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface)",
      padding: "0 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      display: "block",
      paddingBottom: 8,
      color: "var(--ink-muted)"
    }
  }, "02 | ", p.featuresLabel), p.features.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: f.title,
    className: "grid-12",
    style: {
      borderTop: "var(--border-hairline)",
      padding: "40px 0",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 4",
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: p.surface === "#B8C6BA" ? "#6E8272" : p.surface
    }
  }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("h3", {
    style: {
      ...DISPLAY,
      fontSize: "1.75rem",
      lineHeight: 1.1,
      margin: 0,
      maxWidth: "16ch"
    }
  }, f.title)), /*#__PURE__*/React.createElement("p", {
    className: "body-1",
    style: {
      gridColumn: "5 / span 7",
      margin: 0,
      maxWidth: "62ch"
    }
  }, f.body))));
}

/** 03 | Band — a paper-toned section in one of three shapes:
 *  "grid" (mono cells), "split" (text + placeholder frame), "steps". */
function ProductBand({
  p
}) {
  const b = p.band;
  const accent = p.surface === "#B8C6BA" ? "#6E8272" : p.surface;
  const head = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: accent
    }
  }, "03 | ", b.label), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...DISPLAY,
      margin: "16px 0 0",
      fontSize: "clamp(1.9rem, 3vw, 2.5rem)",
      lineHeight: 1.1,
      maxWidth: "22ch"
    }
  }, b.title));
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-paper)",
      padding: "80px 24px",
      borderTop: "var(--border-hairline)",
      borderBottom: "var(--border-hairline)"
    }
  }, b.kind === "split" ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 48,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, head, /*#__PURE__*/React.createElement("p", {
    className: "body-1",
    style: {
      margin: "18px 0 0",
      maxWidth: "46ch",
      color: "var(--ink-muted)"
    }
  }, b.body)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "4 / 3",
      background: "repeating-linear-gradient(135deg, #fff 0 10px, #eceae7 10px 20px)",
      border: "var(--border-hairline)",
      borderRadius: "var(--radius-lg)",
      display: "flex",
      alignItems: "flex-end",
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: "var(--ink-muted)"
    }
  }, b.placeholder))) : /*#__PURE__*/React.createElement("div", null, head, b.kind === "steps" ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${b.items.length}, 1fr)`,
      gap: 1,
      marginTop: 28,
      background: "var(--hairline)",
      border: "var(--border-hairline)"
    }
  }, b.items.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.title,
    style: {
      background: "var(--surface-paper)",
      padding: "22px 18px",
      display: "flex",
      flexDirection: "column",
      gap: 14,
      minHeight: 150
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: accent
    }
  }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
    style: {
      ...DISPLAY,
      fontSize: "1.25rem",
      lineHeight: 1.1
    }
  }, s.title), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: "var(--ink-muted)"
    }
  }, s.body)))) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 1,
      marginTop: 28,
      background: "var(--hairline)",
      border: "var(--border-hairline)"
    }
  }, b.items.map(label => /*#__PURE__*/React.createElement("div", {
    key: label,
    style: {
      background: "var(--surface-paper)",
      padding: "20px 18px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: "var(--ink-muted)"
    }
  }, label))))));
}

/** 04 | Platform — the six-product cross-link grid with "You are here". */
function ProductCrossLinks({
  current
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface)",
      padding: "72px 24px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: "var(--ink-muted)"
    }
  }, "04 | Platform"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(6, 1fr)",
      gap: 1,
      marginTop: 20,
      background: "var(--hairline)",
      border: "var(--border-hairline)"
    }
  }, PRODUCT_META.map(m => {
    const here = m.name === current;
    return /*#__PURE__*/React.createElement("a", {
      key: m.name,
      href: `./${m.name}.html`,
      style: {
        background: here ? "var(--surface-paper)" : "var(--surface)",
        padding: "22px 18px",
        textDecoration: "none",
        color: "var(--ink)",
        display: "flex",
        flexDirection: "column",
        gap: 8,
        transition: "var(--transition-color)"
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.ProductMark, {
      product: m.name,
      kind: "icon",
      height: 15,
      color: m.surface
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        ...DISPLAY,
        fontSize: "1.25rem"
      }
    }, m.name), /*#__PURE__*/React.createElement("span", {
      className: "mono",
      style: {
        color: here ? m.surface === "#B8C6BA" ? "#6E8272" : m.surface : "var(--ink-muted)"
      }
    }, here ? "You are here" : m.short));
  })));
}

/** Closing black band with the product's own call. */
function ProductCta({
  p
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--color-black)",
      color: "var(--color-white)",
      padding: "104px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      ...DISPLAY,
      margin: 0,
      maxWidth: "20ch",
      fontSize: "clamp(2.25rem, 4vw, 3.5rem)",
      lineHeight: 1.05
    }
  }, p.cta.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "light",
    href: p.ctaHref || "#"
  }, p.ctaLabel), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "blurDark",
    href: "./index.html",
    withArrow: true
  }, "Back to Cicero"))));
}

/** The whole subpage. */
function ProductPage({
  p
}) {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": `${p.name} subpage`,
    style: {
      background: "var(--surface)",
      color: "var(--ink)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(ProductHero, {
    p: p
  })), /*#__PURE__*/React.createElement(ProductOverview, {
    p: p
  }), /*#__PURE__*/React.createElement(ProductFeatures, {
    p: p
  }), /*#__PURE__*/React.createElement(ProductBand, {
    p: p
  }), /*#__PURE__*/React.createElement(ProductCrossLinks, {
    current: p.name
  }), /*#__PURE__*/React.createElement(ProductCta, {
    p: p
  }), /*#__PURE__*/React.createElement(__ds_scope.Footer, null));
}
Object.assign(__ds_scope, { PRODUCT_META, ProductHero, ProductOverview, ProductFeatures, ProductBand, ProductCrossLinks, ProductCta, ProductPage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProductPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Statement.jsx
try { (() => {
/** Numbered statement section — full-viewport, sticky-stacking: as the
 *  user scrolls past the hero, each statement fills the screen and the
 *  next one slides up over it (wrap consecutive Statements + the
 *  PlatformStack in one relative parent for the stacking to work).
 *  Plain mono label pinned top-left, large eliza sentence with a
 *  50%-opacity clause centered. */
function Statement({
  label,
  before,
  highlight,
  after,
  detail
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "grid-12",
    style: {
      position: "sticky",
      top: 0,
      minHeight: "100svh",
      background: "var(--surface)",
      padding: 24,
      alignContent: "center",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      position: "absolute",
      top: 24,
      left: 24,
      color: "var(--ink)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / span 10"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "statement-display",
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(2.5rem, 4.6vw, 4.25rem)",
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.05,
      margin: 0,
      textWrap: "balance"
    }
  }, before, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, highlight), after), detail && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 18,
      lineHeight: 1.45,
      maxWidth: "56ch",
      margin: "28px 0 0",
      color: "var(--ink-muted)"
    }
  }, detail)));
}
Object.assign(__ds_scope, { Statement });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Statement.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Link = __ds_scope.Link;

__ds_ns.PullQuote = __ds_scope.PullQuote;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.PixelChevron = __ds_scope.PixelChevron;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Cta = __ds_scope.Cta;

__ds_ns.Customers = __ds_scope.Customers;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Header = __ds_scope.Header;

__ds_ns.Hero = __ds_scope.Hero;

__ds_ns.Impact = __ds_scope.Impact;

__ds_ns.LearnMore = __ds_scope.LearnMore;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.PlatformStack = __ds_scope.PlatformStack;

__ds_ns.ProductMark = __ds_scope.ProductMark;

__ds_ns.PRODUCT_META = __ds_scope.PRODUCT_META;

__ds_ns.ProductHero = __ds_scope.ProductHero;

__ds_ns.ProductOverview = __ds_scope.ProductOverview;

__ds_ns.ProductFeatures = __ds_scope.ProductFeatures;

__ds_ns.ProductBand = __ds_scope.ProductBand;

__ds_ns.ProductCrossLinks = __ds_scope.ProductCrossLinks;

__ds_ns.ProductCta = __ds_scope.ProductCta;

__ds_ns.ProductPage = __ds_scope.ProductPage;

__ds_ns.Statement = __ds_scope.Statement;

})();
