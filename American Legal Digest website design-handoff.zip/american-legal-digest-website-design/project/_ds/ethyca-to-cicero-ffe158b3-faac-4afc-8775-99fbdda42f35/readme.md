# Cicero Design System

The brand and UI system for **Cicero** — *a plataforma jurídica com IA* (the AI
legal platform). This system captures Cicero's editorial, near-monochrome
aesthetic: a high-contrast serif (eliza) for display, a geometric grotesque
(basierSquare) for body, monospace labels for metadata, hairline dividers, and a
green-led accent system.

> **Sharing:** set the file type to **Design System** in the Share menu so others
> in your org can use it.

---

## Company context

Cicero is the platform for modern legal practice — a lawyer network, a client
marketplace, AI drafting, the firm's document memory, an assistant that works
where you do, and the operating system that runs the practice. It is
**Portuguese-first** (Português · English · Español) and built for Brazilian
legal work, producing *finished* work — real documents, tracked changes, signed
contracts, filed records — not just chat. The platform is six products:

| Product | Role |
| --- | --- |
| **Foederati** | The network — where independent lawyers package their expertise into sellable products |
| **Feira** | The marketplace — where clients buy finished legal work at fixed scope and price |
| **Scriba** | Drafting & redlining — first drafts and markups in minutes, built for how lawyers write |
| **Custodia** | The firm's memory — every contract and document, organized, tracked, findable |
| **Magus** | The AI assistant — meets you where you already work: WhatsApp, email, anywhere |
| **Stoa** | The operating system — intake, matters, and tasks in order, so the practice runs |

One assistant persona — **Cicero Intern** — runs through the products, multilingual
and fluent in Brazilian court data. Customers span modern legal teams: full-service
firms, boutique litigation, in-house legal, tax & advisory, labor and civil
practice, real estate, corporate / M&A, and compliance.

### Sources
- The live Cicero product surfaces and the `templates/cicero-site/` marketing site.
- The editorial token system (type, color, spacing, motion) and the `eliza` /
  `basierSquare` / `basierSquareMono` webfonts are the shared foundation across
  every Cicero surface.

---

## Content fundamentals

How Cicero writes:

- **Declarative, professional, confident.** Short statement sentences:
  *"Finished legal work — drafted, reviewed, signed, filed."* / *"A senior legal
  partner in your pocket. Just text it."* Nouns over adjectives; no hype words.
- **Numbered narrative.** Sections and platform steps are numbered in mono —
  `01 | Problem`, `02 | Solution`, `1 · For lawyers`. The number is full-strength
  ink, the label is muted.
- **De-emphasis as emphasis.** Key clauses inside a headline are set at **50%
  opacity**, not in a colour — the eye lands on the full-strength text first.
- **Voice:** addresses the practitioner ("your associates", "the firm answers"),
  speaks plainly about real legal work (drafting, redlining, signing, filing).
- **Casing:** sentence case for headings and body; UPPERCASE only for mono labels.
- **Multilingual by default.** Português · English · Español, surfaced in mono.
- **No emoji.** No exclamation marks. Punctuation is sparse and precise.
- **Product names** are proper nouns set large in the serif display face (eliza).

---

## Visual foundations

- **Palette — near-monochrome + a green-led accent system.** Cool charcoal ink
  (`--color-minos` `#2B2E35`) on white/paper, deepest fields in pure black (hero,
  CTA) and `--color-dark-minos` `#12151C` (button hovers, inputs). Light surfaces
  ramp through marble `#CDD2D3`, limestone `#F1EFEE`, corinth `#FAFAFA`, sandstone
  `#CECAC2`; `grey #757575` is secondary UI text. The six products carry a
  **green-led role system** of band colours: Foederati evergreen `#2B4631`, Feira
  bronze-green `#6F6842`, Scriba inked-sage `#53635F`, Custodia sage-stone
  `#B8C6BA` (light), Magus teal-ink `#2F4648`, Stoa green `#486140`. Muted earth
  accents — terracotta `#B9704B`, olive `#999B83`, sage `#9ABD93` — and an
  extended earthen-red ramp (oxblood `#80352F`, brick `#A24A3C`, madder `#C15F4D`,
  clay red `#CF7C65`, rosewood `#DA9C94`) remain available as punctuation. Colour
  is never used in large fields outside the product bands — the system is
  overwhelmingly ink-on-paper.
- **Dashboard cards — fixed palette (the exception).** Any dashboard built of
  coloured cards — product grids, summary tiles, status cards — uses a dedicated
  six-colour set, codified as `--dash-card-1…6`: teal-ink `#2F4648`, forest
  `#0B301A`, terracotta `#B9704B`, chartreuse `#CBFF89`, oxblood `#80352F`, jade
  `#388F75`, accented in Stoa green `#486140`. **Always use these for dashboard
  cards.** The older green-role ladder (`--dash-card-*-legacy`) stays available as
  an option. This is the one place colour fills large surfaces.
- **Section theming ("color-changer").** Whole sections are themed by overriding
  `--background`/`--foreground` inline. The homepage ramp: black (hero) → white
  (statements) → the platform stack of green product bands → white (customers) →
  black (CTA) → minos (footer).
- **Type.** `eliza` (high-contrast serif) for *all* headings, pull quotes, and product
  descriptions — tracking `-0.03em`, line-height `1.1`, sentence case.
  `basierSquare` (geometric grotesque, has italic) for body at line-height `1.4`.
  `basierSquareMono` for eyebrows, numbered labels, captions — UPPERCASE, `+0.05em`.
  Headings scale up at ≥1920px (editorial big-type moment).
- **Layout.** Strict 12-column grid (4 columns on mobile), `1rem` gutters, `1.5rem`
  section padding. Content is organised in numbered horizontal bands.
- **Dividers.** Hairlines (`1px solid #DFDFDF`) and the signature **dashed rule**
  (1px dash / 4px gap, horizontal + vertical variants). Customer grid cells carry a
  dashed top rule. **Shadows are essentially never used** — separation is by line
  and surface tone.
- **Corners.** Buttons and chips are **2px** (`--radius-xs`, the site's `rounded-2`);
  cards 4–8px; large media frames up to `~40px`. Nothing is pill-rounded except dots.
- **Buttons.** Compact pills, 48px tall, basierSquare at line-height 1, **2px radius**,
  often **split**: label segment + 48px square icon segment with a 1px gap, both
  hovering together. Exact fills: primary minos→dark-minos; white→dark-minos (text
  flips white); on coloured product bands a translucent white fill → solid white;
  footer black→white.
- **Motion.** Calm and expo-eased — `--ease-expo-out` `cubic-bezier(.16,1,.3,1)`
  over `300ms`. Hover = colour/opacity shift (links go olive; nav siblings dim;
  footer links get a **white capsule** behind dark text). The platform section
  **sticky-stacks** product bands as you scroll. Nothing bounces or scales on press.
- **Footer.** A full-viewport-height ink (`#2B2E35`) composition: mono link columns
  (sub-links prefixed with `↳`), a giant **Cicero** serif logotype, newsletter form
  (dark-minos input + black Subscribe button), and mono info/legal columns.
- **Imagery.** Cool, desaturated, editorial photography and dark data-viz. Product
  and brand names are set as serif wordmarks, never as icon glyphs.

---

## Iconography

- The brand's icon language is **pixel-art / dot-matrix**: tiny 1×1 rects forming
  glyphs — the split-button **pixel chevron** (`assets/icons/chevron-pixel.svg`),
  the **pixel arrow** hover marker (`assets/icons/arrow-pixel.svg`). It echoes the
  dashed 1px/4px rules — a dotted, technical aesthetic. A conventional external-link
  icon (`assets/icons/external-link.svg`) appears in rich text. There is **no icon
  font** and **no emoji**, ever.
- **Marks.** The **Cicero** logotype and all six product names (Foederati, Feira,
  Scriba, Custodia, Magus, Stoa) are set as **serif wordmarks in eliza** — there are
  no separate icon glyphs for the products. Where a product needs a small marker, a
  rotated-square (diamond) dot in the current ink is used.
- When new icons are needed, match the pixel/dot-matrix style; prefer SVG; never
  use emoji or unicode glyphs as icons (the one exception: `↳` prefixes footer
  sub-links as *text*, not as an icon).

---

## Index / manifest

**Tokens** (`styles.css` imports all):
- `tokens/fonts.css` — `@font-face` for eliza, basierSquare (+italic), basierSquareMono
- `tokens/colors.css` — palette + semantic aliases (`--ink`, `--surface*`, `--accent`…) + the dashboard-card palette (`--dash-card-1…6`, `--dash-accent`)
- `tokens/typography.css` — families, weights, type scale, mono/tracking tokens
- `tokens/spacing.css` — spacing, radius, borders, dashed rule, motion/easing
- `tokens/base.css` — element styles + helpers (`.eyebrow`, `.body-1`, `.dashed-rule`, `.grid-12`)

**Components**:
- `components/core/` — `Button`, `Eyebrow`, `Tag`, `Card`.
- `components/accents/` — `Stat`, `Link`, `PullQuote`: colour-as-punctuation
  primitives that read `--accent`, so they re-theme with the active section accent.

**UI kit** (`ui_kits/website/`): full homepage recreation — `Header`, `Hero`,
`Statement`, `PlatformStack`, `Customers`, `Cta`, `Footer`, `Logo` + `index.html`.

**Templates** (`templates/`): the full Cicero marketing site
(`templates/cicero-site/`) and the Stoa **Requester Workspace**
(`templates/requester-workspace/`).

**Foundation cards** (`cards/`): Colors, Type, Spacing, Brand specimens shown in the
Design System tab.

**Assets** (`assets/`): brand fonts (`fonts/`) and pixel icons (`icons/`). Product
and brand names are rendered as serif type, not bundled SVG marks.

Components are reachable at `window.EthycaDesignSystem_95c503.<Name>` after loading
`_ds_bundle.js`.
